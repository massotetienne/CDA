import React from 'react';
import Navigation from '../components/Navigation';
import Logo from '../components/Logo';
import MeteoJour from '../components/MeteoJour';

const Meteo = () => {
    return (
        <div>
            <Logo/>
            <Navigation/>
            <MeteoJour/>
           <h1>Meteo</h1> 
        </div>
    );
};

export default Meteo;