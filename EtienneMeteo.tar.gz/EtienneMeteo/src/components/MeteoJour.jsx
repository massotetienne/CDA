import React, { useEffect, useState } from 'react';
import axios from 'axios';


const MeteoJour = ()=> {
    const [data , setData] = useState ([]);
    const [playOnce , setPlayOnce] = useState(true)


    useEffect(() => {
            axios
                .get(
                    "http://api.openweathermap.org/data/2.5/forecast?id=524901&appid=10b3121d6186d24c5659a8de3b72557c"
                )
                .then((res) =>
                    setData(res.data)); 
                    console.log(data);          
        }
       
    
    )}
export default MeteoJour;